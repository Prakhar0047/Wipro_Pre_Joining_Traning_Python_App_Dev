a_file = open("Q2.txt")
number_of_lines = 3

for i in range(number_of_lines):

    line = a_file.readline()
    print(line)