file1 = open("Q3.txt", "a")  # append mode
file1.write("--10,11,12 \n")
file1.close()