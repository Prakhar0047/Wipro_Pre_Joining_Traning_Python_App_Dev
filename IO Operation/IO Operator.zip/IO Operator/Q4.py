a_file = open("Q4.txt")
line = a_file.readline()
ll = []
ll.append(line)
print(ll)